export class DatosReceptor {
    _id: string;
    nombre: string;
    rfc: string;
    estatus: boolean;
    numserie:number;
    calle: string;
    numint: number;
    numext: number;
    codigopostal: number;
    municipio: string;
    localidad: string;
    estado: string;
    razons: string;
}