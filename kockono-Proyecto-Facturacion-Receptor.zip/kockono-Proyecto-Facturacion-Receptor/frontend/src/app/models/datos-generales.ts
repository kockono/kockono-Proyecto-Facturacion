export class DatosReceptor {

cfdi: String;
importe: Number;
subtotal: Number;
total: Number;
iva: Number;

}