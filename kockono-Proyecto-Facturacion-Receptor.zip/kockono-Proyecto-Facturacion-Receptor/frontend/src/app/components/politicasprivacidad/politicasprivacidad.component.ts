import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-politicasprivacidad',
  templateUrl: './politicasprivacidad.component.html',
  styleUrls: ['./politicasprivacidad.component.css']
})
export class PoliticasprivacidadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
