import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-receptor',
  templateUrl: './receptor.component.html',
  styleUrls: ['./receptor.component.css']
})
export class ReceptorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
