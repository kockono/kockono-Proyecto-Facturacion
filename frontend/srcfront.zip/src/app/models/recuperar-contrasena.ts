export class RecuperarContrasena {
    password: string;
    password2: string;
}