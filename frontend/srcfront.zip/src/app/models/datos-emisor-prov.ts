export class DatosEmisorProv {
    _id: string;
    email: string;
    nombreDeLaEmpresa: string;
    calle: string;
    colonia: string;
    estado: string;
    metodo:string;
    estatus:string;
    dias:number;
    numExterior:string;
    numInterior:string;
    cp:string;
    rfc:string;
    municipio:string;
    pais:string;
    telefono:number;
    localidad:string;
    razon:string;
    backup:boolean;
  }
